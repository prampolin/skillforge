# Phase 00 — Inventory & Baseline

**Status:** not-started  
**Last reviewed:** 2026-10-07  
**Dependencies:** None  
**Purpose:** Inventory the existing Next.js 16 project and skills before changing architecture.

## Scope and tasks

- [ ] **00.01 — Record the current file tree, package scripts, lockfile and Git status**  
  Acceptance: Baseline report includes versions and current commands.
- [ ] **00.02 — Inspect AGENTS.md, skills and EVAL-001 artifacts**  
  Acceptance: Existing work is catalogued without overwriting files.
- [ ] **00.03 — Run existing safe typecheck/lint/test commands where available**  
  Acceptance: Actual pass/fail/not-configured evidence is recorded.
- [ ] **00.04 — Document architectural decisions in docs/decisions/**  
  Acceptance: Decisions for local-first, orchestration and data storage are recorded.

## Verification and evidence

- Evidence destination: `docs/architecture/current-state.md` (create or update when implementing).
- Record the exact check command, exit result, observed behavior, and any limitations in the Progress log.
- Never invent results or mark work done based on planned output.

## Out of scope

- Do not perform unrelated refactors or upgrade libraries solely to finish this phase.
- Do not make paid model calls without explicit approval.

## Progress log

| Date (UTC or with timezone) | Item | Change / evidence | Result |
|---|---|---|---|
| — | — | No execution recorded yet | not-started |
